# 🚀 Release v0.0.5

## What's Changed 🌟

### 🔄 Changes since v0.0.4

### 🐛 Bug Fixes

* hotfix auto select starter template works without github token #release ([#959](https://github.com/stackblitz-labs/bolt.diy/pull/959)) by @thecodacus


## 📈 Stats

**Full Changelog**: [`v0.0.4..v0.0.5`](https://github.com/stackblitz-labs/bolt.diy/compare/v0.0.4...v0.0.5)
